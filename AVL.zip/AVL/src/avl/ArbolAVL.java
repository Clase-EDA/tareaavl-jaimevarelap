/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package avl;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Queue;

/**
 *
 * @author jaimevarela
 * @param <T>
 */
public class ArbolAVL<T extends Comparable<T>> {
    
    public NodoAVL raiz;

    public ArbolAVL(NodoAVL raiz) {
        this.raiz = raiz;
    }
    
    public ArbolAVL() {
        this.raiz = null;
    }
    
    public boolean isEmpty(){
        return raiz==null;
    }
    
    public Iterator<T> preorden(){
        ArrayList<T> lista = new ArrayList<>();
        preorden(raiz,lista);
        return lista.iterator();
    }

    private void preorden(NodoAVL<T> actual, ArrayList<T> lista) {
        NodoAVL<T> izq = actual.izq;
        NodoAVL<T> der = actual.der;
        lista.add(actual.dato);
        if(izq!=null) preorden(izq,lista);
        if(der!=null) preorden(der,lista);
    }
    
    public void imprimirPorNiveles(){
        Queue<NodoAVL<T>> cola = new LinkedList(); 
        NodoAVL<T> actual = raiz;
        cola.add(actual); 
        String st;

        while(!cola.isEmpty()){
            actual = cola.poll();
            st="";
            if(actual!=null){
                if (actual.izq != null){
                    cola.add(actual.izq);
                }
                if (actual.der != null){
                    cola.add(actual.der);
                }
                st=actual.dato.toString()+", eq: "+getEquilibrio(actual);
            }
            System.out.println(st);
        }
    }
    
    public NodoAVL<T> buscar(T dato){
        if(raiz!=null){
            return buscar(raiz,dato);
        }
        return null;
    }
    
    private NodoAVL<T> buscar(NodoAVL<T> actual, T dato){
        if(actual!=null){
            if(dato.compareTo(actual.dato)<0){
                return buscar(actual.izq,dato);
            }
            else if(dato.compareTo(actual.dato)>0){
                return buscar(actual.der,dato);
            }
            else{
                return actual;
            }
        }
        return null;
    }
    
    private int altura(NodoAVL nodo) { 
        if (nodo == null) 
            return 0; 
  
        return nodo.altura; 
    }
    
    private int getEquilibrio(NodoAVL nodo){
        if(nodo==null){
            return 0;
        }
        return altura(nodo.der)-altura(nodo.izq);
    }
    
    public void insertar(T dato){
        NodoAVL nR = insertar(raiz,dato);
        raiz = nR;
    }

    private NodoAVL<T> insertar(NodoAVL<T> actual, T dato) {
        if(actual==null){
            return new NodoAVL(dato);
        }
        
        if(dato.compareTo(actual.dato)<0){
            actual.izq = insertar(actual.izq,dato);
        }
        else{
            actual.der = insertar(actual.der,dato);
        }
        
        actual.altura = 1+Math.max(altura(actual.izq),altura(actual.der));
        int eq = getEquilibrio(actual);
        
        if(eq<-1){
            if(dato.compareTo((T)actual.izq.dato)<0){
                return rotarIzquierda(actual);
            }
            else{
                actual.izq = rotarDerecha(actual.izq);
            return rotarIzquierda(actual);
            }
        }
        if(eq>1){
            if(dato.compareTo((T)actual.der.dato)>0){
                return rotarDerecha(actual);
            }
            else{
                actual.der = rotarIzquierda(actual.der);
                return rotarDerecha(actual);
            }
        }
        return actual;
    }
    
    public void borrar(T dato){
        NodoAVL nR = borrar(raiz,dato);
        raiz = nR;
    }
    
    private NodoAVL<T> borrar(NodoAVL<T> actual, T dato){
        if(actual==null){
            return actual;
        }
        if(dato.compareTo(actual.dato)<0){
            actual.izq = borrar(actual.izq,dato);
        }
        else if(dato.compareTo(actual.dato)>0){
            actual.der = borrar(actual.der,dato);
        }
        else{
            NodoAVL aux;
            if(actual.izq==null||actual.der==null){
                if(actual.izq==null){
                    aux = actual.der;
                }
                else{
                    aux = actual.izq;
                }
                
                if(aux==null){
                    actual=null;
                }
                else{
                    actual=aux;
                }
            }
            else{
                aux=actual.der;
                while(aux.izq!=null){
                    aux=aux.izq;
                }
                actual.dato = (T)aux.dato;
                actual.der = borrar(actual.der, (T)aux.dato);
            }
        }
        if(actual==null){
            return actual;
        }
        actual.altura = Math.max(altura(actual.izq),altura(actual.der))+1;
        int eq = getEquilibrio(actual);
        
        if(eq<-1){
            if(getEquilibrio(actual.izq)<=0){
                return rotarIzquierda(actual);
            }
            else{
                actual.izq = rotarDerecha(actual.izq);
                return rotarIzquierda(actual);
            }
        }
        if(eq>1){
            if(getEquilibrio(actual.der)>=0){
                return rotarDerecha(actual);
            }
            else{
                actual.der = rotarIzquierda(actual.der);
                return rotarDerecha(actual);
            }
        }
        return actual;
    }

    private NodoAVL<T> rotarIzquierda(NodoAVL<T> nodo) {
        NodoAVL A = nodo.izq;
        NodoAVL B = A.der;
        
        A.der = nodo;
        nodo.izq = B;
        
        nodo.altura = Math.max(altura(nodo.izq),altura(nodo.der))+1;
        A.altura = Math.max(altura(A.izq),altura(A.der))+1;
        
        return A;
    }

    private NodoAVL<T> rotarDerecha(NodoAVL<T> nodo) {
        NodoAVL A = nodo.der;
        NodoAVL B = A.izq;
        
        A.izq = nodo;
        nodo.der = B;
        
        nodo.altura = Math.max(altura(nodo.izq),altura(nodo.der))+1;
        A.altura = Math.max(altura(A.izq),altura(A.der))+1;
        
        return A;
    }
}
