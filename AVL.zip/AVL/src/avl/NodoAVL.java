package avl;

/**
 * @author jaimevarela
 * @param <T>
 */

public class NodoAVL<T extends Comparable<T>> {
    
    public NodoAVL izq;
    public NodoAVL der;
    public T dato;
    public int altura;

    public NodoAVL(T dato) {
        this.dato = dato;
        this.altura = 1;
    }

}
